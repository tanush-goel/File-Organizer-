import json
import tempfile
import unittest
from pathlib import Path

from file_organizer.cli import main
from file_organizer.organizer import (
    category_for,
    execute_moves,
    load_categories,
    plan_moves,
    undo_last_run,
)


def touch(folder: Path, *names: str) -> None:
    for name in names:
        path = folder / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(name, encoding="utf-8")


class CategoryTests(unittest.TestCase):
    def setUp(self):
        self.cats = load_categories()

    def test_basic_extensions(self):
        self.assertEqual(category_for(Path("a.PNG"), self.cats), "Images")
        self.assertEqual(category_for(Path("a.pdf"), self.cats), "Documents")
        self.assertEqual(category_for(Path("a.mp3"), self.cats), "Audio")

    def test_compound_extension(self):
        self.assertEqual(category_for(Path("backup.tar.gz"), self.cats), "Archives")

    def test_unknown_and_no_extension_go_to_other(self):
        self.assertEqual(category_for(Path("weird.xyz"), self.cats), "Other")
        self.assertEqual(category_for(Path("Makefile"), self.cats), "Other")

    def test_custom_config(self):
        with tempfile.TemporaryDirectory() as tmp:
            cfg = Path(tmp) / "cfg.json"
            cfg.write_text(json.dumps({"Books": ["epub", ".MOBI"]}), encoding="utf-8")
            cats = load_categories(cfg)
        self.assertEqual(cats, {"Books": [".epub", ".mobi"]})

    def test_bad_config_raises(self):
        with tempfile.TemporaryDirectory() as tmp:
            cfg = Path(tmp) / "cfg.json"
            cfg.write_text(json.dumps(["not", "a", "dict"]), encoding="utf-8")
            with self.assertRaises(ValueError):
                load_categories(cfg)


class OrganizeTests(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.root = Path(self._tmp.name)
        self.cats = load_categories()

    def tearDown(self):
        self._tmp.cleanup()

    def test_plan_does_not_touch_disk(self):
        touch(self.root, "a.png", "b.pdf")
        moves = plan_moves(self.root, self.cats)
        self.assertEqual(len(moves), 2)
        self.assertTrue((self.root / "a.png").exists())
        self.assertFalse((self.root / "Images").exists())

    def test_execute_moves_files(self):
        touch(self.root, "a.png", "b.pdf", "c.zip")
        moved, errors = execute_moves(self.root, plan_moves(self.root, self.cats))
        self.assertEqual(len(moved), 3)
        self.assertEqual(errors, [])
        self.assertTrue((self.root / "Images" / "a.png").exists())
        self.assertTrue((self.root / "Documents" / "b.pdf").exists())
        self.assertTrue((self.root / "Archives" / "c.zip").exists())

    def test_name_collision_never_overwrites(self):
        touch(self.root, "Documents/report.pdf", "report.pdf")
        execute_moves(self.root, plan_moves(self.root, self.cats))
        self.assertTrue((self.root / "Documents" / "report.pdf").exists())
        self.assertTrue((self.root / "Documents" / "report (1).pdf").exists())

    def test_collision_inside_one_run(self):
        touch(self.root, "x/a.png", "y/a.png")
        moves = plan_moves(self.root, self.cats, recursive=True)
        self.assertEqual(len({m.dst for m in moves}), 2)

    def test_hidden_and_partial_files_skipped(self):
        touch(self.root, ".secret.png", "movie.mp4.crdownload", "real.png")
        moves = plan_moves(self.root, self.cats)
        self.assertEqual([m.src.name for m in moves], ["real.png"])

    def test_hidden_included_on_request(self):
        touch(self.root, ".secret.png")
        moves = plan_moves(self.root, self.cats, include_hidden=True)
        self.assertEqual(len(moves), 1)

    def test_non_recursive_ignores_subfolders(self):
        touch(self.root, "sub/deep.png", "top.png")
        moves = plan_moves(self.root, self.cats)
        self.assertEqual([m.src.name for m in moves], ["top.png"])

    def test_recursive_skips_already_organized_folders(self):
        touch(self.root, "Images/done.png", "sub/new.png")
        moves = plan_moves(self.root, self.cats, recursive=True)
        self.assertEqual([m.src.name for m in moves], ["new.png"])

    def test_undo_restores_everything(self):
        touch(self.root, "a.png", "b.pdf")
        execute_moves(self.root, plan_moves(self.root, self.cats))
        restored, skipped = undo_last_run(self.root)
        self.assertEqual((restored, skipped), (2, 0))
        self.assertTrue((self.root / "a.png").exists())
        self.assertTrue((self.root / "b.pdf").exists())
        self.assertFalse((self.root / "Images").exists())
        self.assertFalse((self.root / ".file_organizer_log.json").exists())

    def test_undo_with_no_history(self):
        self.assertIsNone(undo_last_run(self.root))

    def test_undo_only_reverses_last_run(self):
        touch(self.root, "a.png")
        execute_moves(self.root, plan_moves(self.root, self.cats))
        touch(self.root, "b.pdf")
        execute_moves(self.root, plan_moves(self.root, self.cats))
        undo_last_run(self.root)
        self.assertTrue((self.root / "b.pdf").exists())
        self.assertTrue((self.root / "Images" / "a.png").exists())

    def test_not_a_folder(self):
        with self.assertRaises(NotADirectoryError):
            plan_moves(self.root / "nope", self.cats)


class CliTests(unittest.TestCase):
    def test_dry_run_changes_nothing(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            touch(root, "a.png")
            self.assertEqual(main([str(root), "--dry-run", "-q"]), 0)
            self.assertTrue((root / "a.png").exists())

    def test_full_run_and_undo(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            touch(root, "a.png", "b.mp3")
            self.assertEqual(main([str(root), "-q"]), 0)
            self.assertTrue((root / "Images" / "a.png").exists())
            self.assertEqual(main([str(root), "--undo"]), 0)
            self.assertTrue((root / "a.png").exists())

    def test_missing_folder_errors(self):
        self.assertEqual(main(["/definitely/not/here"]), 2)


if __name__ == "__main__":
    unittest.main()
