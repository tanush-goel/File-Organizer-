"""Command-line interface."""

from __future__ import annotations

import argparse
import sys
from collections import Counter
from pathlib import Path

from . import __version__
from .organizer import execute_moves, load_categories, plan_moves, undo_last_run


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="file-organizer",
        description="Sort the files in a folder into category folders (Images, Documents, ...).",
    )
    parser.add_argument("folder", nargs="?", default="~/Downloads",
                        help="folder to organize (default: ~/Downloads)")
    parser.add_argument("-n", "--dry-run", action="store_true",
                        help="show what would happen without moving anything")
    parser.add_argument("-r", "--recursive", action="store_true",
                        help="also organize files inside subfolders")
    parser.add_argument("-c", "--config", metavar="FILE",
                        help="JSON file with your own categories")
    parser.add_argument("--include-hidden", action="store_true",
                        help="also move hidden files (names starting with a dot)")
    parser.add_argument("-u", "--undo", action="store_true",
                        help="undo the most recent run in this folder")
    parser.add_argument("-q", "--quiet", action="store_true",
                        help="only print the final summary")
    parser.add_argument("-v", "--version", action="version", version=f"%(prog)s {__version__}")
    return parser


def _summary(moves) -> str:
    counts = Counter(m.category for m in moves)
    return ", ".join(f"{cat}: {n}" for cat, n in sorted(counts.items()))


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    folder = Path(args.folder).expanduser()

    if not folder.is_dir():
        print(f"error: '{folder}' is not a folder", file=sys.stderr)
        return 2

    if args.undo:
        result = undo_last_run(folder)
        if result is None:
            print("Nothing to undo in this folder.")
            return 0
        restored, skipped = result
        print(f"Undone: {restored} file(s) restored, {skipped} skipped.")
        return 0

    try:
        categories = load_categories(args.config)
        moves = plan_moves(folder, categories, args.recursive, args.include_hidden)
    except (OSError, ValueError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2

    if not moves:
        print("Nothing to organize. The folder is already tidy!")
        return 0

    if args.dry_run:
        if not args.quiet:
            for m in moves:
                print(f"  {m.src.name}  ->  {m.category}/")
        print(f"\nDry run: {len(moves)} file(s) would be moved ({_summary(moves)}).")
        return 0

    moved, errors = execute_moves(folder, moves)
    if not args.quiet:
        for m in moved:
            print(f"  {m.src.name}  ->  {m.category}/")
    print(f"\nMoved {len(moved)} file(s) ({_summary(moved)}).")
    if errors:
        print(f"{len(errors)} file(s) could not be moved:", file=sys.stderr)
        for move, reason in errors:
            print(f"  {move.src.name}: {reason}", file=sys.stderr)
        return 1
    print("Changed your mind? Run again with --undo to put everything back.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
