"""Default file-type categories.

Each category maps to a list of lowercase extensions (with the leading dot).
Compound extensions such as ".tar.gz" are supported.
"""

FALLBACK_CATEGORY = "Other"

DEFAULT_CATEGORIES = {
    "Images": [
        ".jpg", ".jpeg", ".png", ".gif", ".bmp", ".webp", ".svg", ".tiff",
        ".heic", ".ico", ".raw",
    ],
    "Videos": [".mp4", ".mkv", ".mov", ".avi", ".wmv", ".flv", ".webm", ".m4v"],
    "Audio": [".mp3", ".wav", ".flac", ".aac", ".ogg", ".m4a", ".wma"],
    "Documents": [
        ".pdf", ".doc", ".docx", ".txt", ".rtf", ".odt", ".md", ".epub",
        ".pages",
    ],
    "Spreadsheets": [".xls", ".xlsx", ".csv", ".ods", ".tsv", ".numbers"],
    "Presentations": [".ppt", ".pptx", ".odp", ".key"],
    "Archives": [".zip", ".rar", ".7z", ".tar", ".gz", ".bz2", ".tar.gz", ".tgz"],
    "Code": [
        ".py", ".js", ".ts", ".html", ".css", ".java", ".c", ".cpp", ".h",
        ".go", ".rs", ".rb", ".php", ".sh", ".json", ".yaml", ".yml", ".sql",
        ".ipynb",
    ],
    "Installers": [".exe", ".msi", ".dmg", ".pkg", ".deb", ".rpm", ".apk"],
    "Fonts": [".ttf", ".otf", ".woff", ".woff2"],
}

# Files still being downloaded or temporary; never moved.
SKIP_EXTENSIONS = {".crdownload", ".part", ".partial", ".tmp", ".download"}
