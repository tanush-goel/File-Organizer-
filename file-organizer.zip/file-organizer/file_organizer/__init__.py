"""file-organizer: sort a messy folder into tidy category folders."""

__version__ = "1.0.0"
