"""Core logic: plan moves, execute them, and undo them.

Planning never touches the disk, so a dry run is always safe.
"""

from __future__ import annotations

import json
import shutil
import time
from dataclasses import dataclass
from pathlib import Path

from .categories import DEFAULT_CATEGORIES, FALLBACK_CATEGORY, SKIP_EXTENSIONS

LOG_NAME = ".file_organizer_log.json"


@dataclass(frozen=True)
class Move:
    src: Path
    dst: Path

    @property
    def category(self) -> str:
        return self.dst.parent.name


# --------------------------------------------------------------------------
# Categories
# --------------------------------------------------------------------------

def _normalize_ext(ext: str) -> str:
    ext = ext.strip().lower()
    return ext if ext.startswith(".") else "." + ext


def load_categories(config_path: str | Path | None = None) -> dict[str, list[str]]:
    """Return the category map, from a JSON config file or the defaults."""
    if config_path is None:
        return {name: list(exts) for name, exts in DEFAULT_CATEGORIES.items()}

    data = json.loads(Path(config_path).read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        raise ValueError("Config must be a JSON object: {\"Category\": [\".ext\", ...]}")

    categories: dict[str, list[str]] = {}
    for name, exts in data.items():
        if not isinstance(exts, list) or not all(isinstance(e, str) for e in exts):
            raise ValueError(f"Category {name!r} must map to a list of extension strings")
        categories[name] = [_normalize_ext(e) for e in exts]
    return categories


def category_for(path: Path, categories: dict[str, list[str]]) -> str:
    """Pick the category for a file, supporting compound extensions (.tar.gz)."""
    lookup = {ext: name for name, exts in categories.items() for ext in exts}
    suffixes = [s.lower() for s in path.suffixes]

    if len(suffixes) >= 2:
        compound = "".join(suffixes[-2:])
        if compound in lookup:
            return lookup[compound]
    if suffixes and suffixes[-1] in lookup:
        return lookup[suffixes[-1]]
    return FALLBACK_CATEGORY


# --------------------------------------------------------------------------
# Planning
# --------------------------------------------------------------------------

def unique_destination(dst: Path, reserved: set[Path]) -> Path:
    """Return a path that doesn't exist and isn't already planned.

    "report.pdf" becomes "report (1).pdf", "report (2).pdf", ...
    """
    if not dst.exists() and dst not in reserved:
        return dst
    counter = 1
    while True:
        candidate = dst.with_name(f"{dst.stem} ({counter}){dst.suffix}")
        if not candidate.exists() and candidate not in reserved:
            return candidate
        counter += 1


def _candidate_files(source: Path, category_names: set[str],
                     recursive: bool, include_hidden: bool) -> list[Path]:
    if not recursive:
        files = [p for p in source.iterdir() if p.is_file()]
    else:
        files = []
        for p in source.rglob("*"):
            if not p.is_file():
                continue
            rel_parts = p.relative_to(source).parts
            if rel_parts[0] in category_names:  # already organized
                continue
            files.append(p)

    result = []
    for p in sorted(files):
        rel_parts = p.relative_to(source).parts
        if p.name == LOG_NAME:
            continue
        if not include_hidden and any(part.startswith(".") for part in rel_parts):
            continue
        if p.suffix.lower() in SKIP_EXTENSIONS:
            continue
        result.append(p)
    return result


def plan_moves(source: str | Path, categories: dict[str, list[str]],
               recursive: bool = False, include_hidden: bool = False) -> list[Move]:
    """Work out where every file should go, without moving anything."""
    source = Path(source).expanduser().resolve()
    if not source.is_dir():
        raise NotADirectoryError(f"Not a folder: {source}")

    category_names = set(categories) | {FALLBACK_CATEGORY}
    reserved: set[Path] = set()
    moves: list[Move] = []

    for path in _candidate_files(source, category_names, recursive, include_hidden):
        category = category_for(path, categories)
        dst = unique_destination(source / category / path.name, reserved)
        reserved.add(dst)
        moves.append(Move(path, dst))
    return moves


# --------------------------------------------------------------------------
# Executing and undoing
# --------------------------------------------------------------------------

def _read_log(log_path: Path) -> list[dict]:
    if not log_path.exists():
        return []
    try:
        return json.loads(log_path.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        return []


def _write_log(log_path: Path, runs: list[dict]) -> None:
    if runs:
        log_path.write_text(json.dumps(runs, indent=2), encoding="utf-8")
    elif log_path.exists():
        log_path.unlink()


def execute_moves(source: str | Path, moves: list[Move]) -> tuple[list[Move], list[tuple[Move, str]]]:
    """Move the files and record the run so it can be undone.

    Returns (moved, errors). One failing file never stops the rest.
    """
    source = Path(source).expanduser().resolve()
    moved: list[Move] = []
    errors: list[tuple[Move, str]] = []

    for move in moves:
        try:
            move.dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.move(str(move.src), str(move.dst))
            moved.append(move)
        except OSError as exc:
            errors.append((move, str(exc)))

    if moved:
        log_path = source / LOG_NAME
        runs = _read_log(log_path)
        runs.append({
            "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
            "moves": [{"src": str(m.src), "dst": str(m.dst)} for m in moved],
        })
        _write_log(log_path, runs)
    return moved, errors


def undo_last_run(source: str | Path) -> tuple[int, int] | None:
    """Reverse the most recent run. Returns (restored, skipped) or None if no history."""
    source = Path(source).expanduser().resolve()
    log_path = source / LOG_NAME
    runs = _read_log(log_path)
    if not runs:
        return None

    run = runs.pop()
    restored = skipped = 0
    for entry in reversed(run["moves"]):
        src, dst = Path(entry["src"]), Path(entry["dst"])
        if not dst.exists() or src.exists():
            skipped += 1
            continue
        src.parent.mkdir(parents=True, exist_ok=True)
        shutil.move(str(dst), str(src))
        restored += 1
        # tidy up category folders that became empty
        try:
            if dst.parent != source:
                dst.parent.rmdir()
        except OSError:
            pass

    _write_log(log_path, runs)
    return restored, skipped
