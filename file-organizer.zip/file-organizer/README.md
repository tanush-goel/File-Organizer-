# file-organizer

Is your Downloads folder a mess? One command sorts everything into tidy folders like `Images/`, `Documents/` and `Archives/`. Zero dependencies, safe by default, and fully undoable.

```
$ file-organizer ~/Downloads --dry-run
  holiday.jpg      ->  Images/
  notes.pdf        ->  Documents/
  setup.exe        ->  Installers/
  project.tar.gz   ->  Archives/

Dry run: 4 file(s) would be moved (Archives: 1, Documents: 1, Images: 1, Installers: 1).
```

## Features

- **Dry run** (`--dry-run`): preview every move before anything happens
- **Undo** (`--undo`): put the last run back exactly as it was
- **Never overwrites**: name clashes become `report (1).pdf`, `report (2).pdf`
- **Smart about extensions**: handles `.tar.gz`, upper/lower case, and files with no extension
- **Skips unfinished downloads** (`.crdownload`, `.part`, `.tmp`) and hidden files
- **Recursive mode** for deep folders
- **Custom categories** via a small JSON file
- **Pure standard library**: nothing to install except Python 3.8+

## Install

```bash
git clone https://github.com/<your-username>/file-organizer.git
cd file-organizer
pip install .
```

Or run it without installing:

```bash
python -m file_organizer ~/Downloads --dry-run
```

## Usage

```bash
file-organizer                       # organize ~/Downloads
file-organizer ~/Desktop             # organize any folder
file-organizer ~/Downloads -n        # dry run (preview only)
file-organizer ~/Downloads -r        # include subfolders
file-organizer ~/Downloads -u        # undo the last run
file-organizer . -c my-config.json   # use your own categories
```

| Option | Meaning |
| --- | --- |
| `-n`, `--dry-run` | Show what would happen, move nothing |
| `-r`, `--recursive` | Also organize files in subfolders |
| `-c`, `--config FILE` | Use your own categories (JSON) |
| `--include-hidden` | Also move hidden files |
| `-u`, `--undo` | Undo the most recent run in that folder |
| `-q`, `--quiet` | Only print the summary |

## Custom categories

Create a JSON file mapping a folder name to its extensions (the leading dot is optional):

```json
{
  "School": [".docx", ".pdf", ".pptx"],
  "Photos": [".jpg", ".png", ".heic"],
  "Books": ["epub", "mobi"]
}
```

Run it with `file-organizer ~/Downloads -c my-config.json`. Files that match nothing go into `Other/`. See `example-config.json`.

## How undo works

Each run is logged in a hidden `.file_organizer_log.json` inside the organized folder. `--undo` reverses the most recent run, moves files back to their original places, and removes category folders that end up empty. Run it again to undo the run before that.

## Tests

```bash
python -m unittest discover -v
```

## Project layout

```
file_organizer/
  categories.py   default categories and skip rules
  organizer.py    plan -> execute -> undo (no side effects while planning)
  cli.py          argparse command-line interface
tests/            unit tests (temporary folders, never your real files)
```

## Ideas for next steps

- Sort by date (`2026/10/`) instead of type
- A `--watch` mode that organizes new files automatically
- Package it for PyPI

## License

MIT
